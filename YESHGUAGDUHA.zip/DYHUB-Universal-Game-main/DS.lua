getgenv().ValiableX = "This Script is own by Valiable X https://discord.gg/bEqje9SsrH"
loadstring(game:HttpGet("https://raw.githubusercontent.com/Idaowldoa/script/refs/heads/main/Dead%20Spells%20auto%20win"))()
