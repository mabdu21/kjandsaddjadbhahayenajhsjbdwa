repeat wait() until game:IsLoaded() 
and game.Players.LocalPlayer
loadstring(game:HttpGet('https://raw.githubusercontent.com/meobeo8/type/main/Loader'))()
