print([[

DYHUB - dsc.gg/dyhub

                                                                        

]])

do
    local WindUI = loadstring(game:HttpGet("https://github.com/Footagesus/WindUI/releases/latest/download/main.lua"))()
    local Players = game:GetService("Players")
    local RunService = game:GetService("RunService")
    local ReplicatedStorage = game:GetService("ReplicatedStorage")
    local Workspace = game:GetService("Workspace")
    local CurrentCamera = Workspace.CurrentCamera
    local LocalPlayer = Players.LocalPlayer
    local CoreGui = game:GetService("CoreGui")
    function gradient(text, startColor, endColor)
        local result = ""
        local length = #text
        for i = 1, length do
            local t = (i - 1) / math.max(length - 1, 1)
            local r = math.floor((startColor.R + ((endColor.R - startColor.R) * t)) * 255)
            local g = math.floor((startColor.G + ((endColor.G - startColor.G) * t)) * 255)
            local b = math.floor((startColor.B + ((endColor.B - startColor.B) * t)) * 255)
            local char = text:sub(i, i)
            result = result .. '<font color="rgb(' .. r .. ", " .. g .. ", " .. b .. ')">' .. char .. "</font>"
        end
        return result
    end
    local Confirmed = false
    WindUI:Popup(
        {
            Title = gradient("DYHUB Loaded! - Murder Mystery 2", Color3.fromHex("#ff0000"), Color3.fromHex("#000000")),
            Icon = "rbxassetid://104487529937663",
            Content = gradient("+ Version: Premium", Color3.fromHex("#ffffff"), Color3.fromHex("#ffffff")) ..
                gradient(" [DYHUB OFFICIAL]", Color3.fromHex("#ff0000"), Color3.fromHex("#000000")),
            Buttons = {
                {Title = gradient("Cancel", Color3.fromHex("#ffffff"), Color3.fromHex("#ffffff")), Callback = function()
                    end, Variant = "Tertiary"},
                {Title = gradient("Load", Color3.fromHex("#90f09e"), Color3.fromHex("#13ed34")), Callback = function()
                        Confirmed = true
                    end, Variant = "Secondary"}
            }
        }
    )
    repeat
        task.wait()
    until Confirmed
    WindUI:Notify(
        {
            Title = gradient("DYHUB", Color3.fromHex("#ff0000"), Color3.fromHex("#000000")),
            Content = "Notification!",
            Icon = "info",
            Duration = 3
        }
    )
    local Window =
        WindUI:CreateWindow(
        {
            Title = gradient("DYHUB - Murder Mystery 2", Color3.fromHex("#ff0000"), Color3.fromHex("#000000")),
            Icon = "rbxassetid://104487529937663",
            Author = gradient("Version: 3.2.8 | Executor", Color3.fromHex("#ffffff"), Color3.fromHex("#ffffff")),
            Folder = "DYHUB_MM2",
            Size = UDim2.fromOffset(500, 300),
            Transparent = true,
            Theme = "Dark",
            SideBarWidth = 200,
            UserEnabled = true,
            HasOutline = true
        }
    )
    Window:EditOpenButton(
        {
            Title = "DYHUB - OPEN",
            Icon = "monitor",
            CornerRadius = UDim.new(2, 6),
            StrokeThickness = 2,
            Color = ColorSequence.new(Color3.fromHex("1E213D"), Color3.fromHex("1F75FE")),
            Draggable = true
        }
    )
    local Tabs = {
        MainTab = Window:Tab(
            {Title = gradient("MAIN", Color3.fromHex("#ffffff"), Color3.fromHex("#636363")), Icon = "rocket"}
        ),
        CharacterTab = Window:Tab(
            {Title = gradient("CHARACTER", Color3.fromHex("#ffffff"), Color3.fromHex("#636363")), Icon = "file-cog"}
        ),
        TeleportTab = Window:Tab(
            {Title = gradient("TELEPORT", Color3.fromHex("#ffffff"), Color3.fromHex("#636363")), Icon = "user"}
        ),
        EspTab = Window:Tab(
            {Title = gradient("ESP", Color3.fromHex("#ffffff"), Color3.fromHex("#636363")), Icon = "eye"}
        ),
        AimbotTab = Window:Tab(
            {Title = gradient("AIMBOT", Color3.fromHex("#ffffff"), Color3.fromHex("#636363")), Icon = "arrow-right"}
        ),
        AutoFarm = Window:Tab(
            {Title = gradient("AUTO FARM", Color3.fromHex("#ffffff"), Color3.fromHex("#636363")), Icon = "user"}
        ),
        bs = Window:Divider(),
        InnocentTab = Window:Tab(
            {Title = gradient("INNOCENT", Color3.fromHex("#0ff707"), Color3.fromHex("#1e690c")), Icon = "circle"}
        ),
        MurderTab = Window:Tab(
            {Title = gradient("MURDER", Color3.fromHex("#e80909"), Color3.fromHex("#630404")), Icon = "circle"}
        ),
        SheriffTab = Window:Tab(
            {Title = gradient("SHERIFF", Color3.fromHex("#16f2d9"), Color3.fromHex("#001e80")), Icon = "circle"}
        ),
        gh = Window:Divider(),
        ServerTab = Window:Tab(
            {Title = gradient("SERVER", Color3.fromHex("#ffffff"), Color3.fromHex("#636363")), Icon = "atom"}
        ),
        SettingsTab = Window:Tab(
            {Title = gradient("SETTINGS", Color3.fromHex("#ffffff"), Color3.fromHex("#636363")), Icon = "code"}
        ),
        ChangelogsTab = Window:Tab(
            {Title = gradient("CHANGELOGS", Color3.fromHex("#ffffff"), Color3.fromHex("#636363")), Icon = "info"}
        ),
        SocialsTab = Window:Tab(
            {Title = gradient("SOCIALS", Color3.fromHex("#ffffff"), Color3.fromHex("#636363")), Icon = "star"}
        ),
        b = Window:Divider(),
        WindowTab = Window:Tab(
            {
                Title = gradient("CONFIGURATION", Color3.fromHex("#ffffff"), Color3.fromHex("#636363")),
                Icon = "settings",
                Desc = "Manage window settings and file configurations."
            }
        ),
        CreateThemeTab = Window:Tab(
            {
                Title = gradient("THEMES", Color3.fromHex("#ffffff"), Color3.fromHex("#636363")),
                Icon = "palette",
                Desc = "Design and apply custom themes."
            }
        )
    }
    local Players = game:GetService("Players")
    local RunService = game:GetService("RunService")
    local LocalPlayer = Players.LocalPlayer
    local CharacterSettings = {
        WalkSpeed = {Value = 16, Default = 16, Locked = false},
        JumpPower = {Value = 50, Default = 50, Locked = false}
    }
    local function updateCharacter()
        local character = LocalPlayer.Character
        local humanoid = character:FindFirstChildOfClass("Humanoid")
        if humanoid then
            if not CharacterSettings.WalkSpeed.Locked then
                humanoid.WalkSpeed = CharacterSettings.WalkSpeed.Value
            end
            if not CharacterSettings.JumpPower.Locked then
                humanoid.JumpPower = CharacterSettings.JumpPower.Value
            end
        end
    end
    Tabs.CharacterTab:Section({Title = gradient("Walkspeed", Color3.fromHex("#ff0000"), Color3.fromHex("#300000"))})
    Tabs.CharacterTab:Slider(
        {Title = "Walkspeed", Value = {Min = 0, Max = 200, Default = 16}, Callback = function(value)
                CharacterSettings.WalkSpeed.Value = value
                updateCharacter()
            end}
    )
    Tabs.CharacterTab:Button(
        {Title = "Reset walkspeed", Callback = function()
                CharacterSettings.WalkSpeed.Value = CharacterSettings.WalkSpeed.Default
                updateCharacter()
            end}
    )
    Tabs.CharacterTab:Toggle(
        {Title = "Block walkspeed", Default = false, Callback = function(state)
                CharacterSettings.WalkSpeed.Locked = state
                updateCharacter()
            end}
    )
    Tabs.CharacterTab:Section({Title = gradient("JumpPower", Color3.fromHex("#ff0000"), Color3.fromHex("#300000"))})
    Tabs.CharacterTab:Slider(
        {Title = "Jumppower", Value = {Min = 0, Max = 200, Default = 50}, Callback = function(value)
                CharacterSettings.JumpPower.Value = value
                updateCharacter()
            end}
    )
    Tabs.CharacterTab:Button(
        {Title = "Reset jumppower", Callback = function()
                CharacterSettings.JumpPower.Value = CharacterSettings.JumpPower.Default
                updateCharacter()
            end}
    )
    Tabs.CharacterTab:Toggle(
        {Title = "Block jumppower", Default = false, Callback = function(state)
                CharacterSettings.JumpPower.Locked = state
                updateCharacter()
            end}
    )
    local ReplicatedStorage = game:GetService("ReplicatedStorage")
    local Players = game:GetService("Players")
    local RunService = game:GetService("RunService")
    local LP = Players.LocalPlayer
    local ESPConfig = {HighlightMurderer = false, HighlightInnocent = false, HighlightSheriff = false}
    local Murder, Sheriff, Hero
    local roles = {}
    function CreateHighlight(player)
        if ((player ~= LP) and player.Character and not player.Character:FindFirstChild("Highlight")) then
            local highlight = Instance.new("Highlight")
            highlight.Parent = player.Character
            highlight.Adornee = player.Character
            highlight.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
            return highlight
        end
        return player.Character and player.Character:FindFirstChild("Highlight")
    end
    function RemoveAllHighlights()
        for _, player in pairs(Players:GetPlayers()) do
            if (player.Character and player.Character:FindFirstChild("Highlight")) then
                player.Character.Highlight:Destroy()
            end
        end
    end
    function UpdateHighlights()
        for _, player in pairs(Players:GetPlayers()) do
            if ((player ~= LP) and player.Character) then
                local highlight = player.Character:FindFirstChild("Highlight")
                if not (ESPConfig.HighlightMurderer or ESPConfig.HighlightInnocent or ESPConfig.HighlightSheriff) then
                    if highlight then
                        highlight:Destroy()
                    end
                    return
                end
                local shouldHighlight = false
                local color = Color3.new(0, 1, 0)
                if ((player.Name == Murder) and IsAlive(player) and ESPConfig.HighlightMurderer) then
                    color = Color3.fromRGB(255, 0, 0)
                    shouldHighlight = true
                elseif ((player.Name == Sheriff) and IsAlive(player) and ESPConfig.HighlightSheriff) then
                    color = Color3.fromRGB(0, 0, 255)
                    shouldHighlight = true
                elseif
                    (ESPConfig.HighlightInnocent and IsAlive(player) and (player.Name ~= Murder) and
                        (player.Name ~= Sheriff) and
                        (player.Name ~= Hero))
                 then
                    color = Color3.fromRGB(0, 255, 0)
                    shouldHighlight = true
                elseif
                    ((player.Name == Hero) and IsAlive(player) and not IsAlive(game.Players[Sheriff]) and
                        ESPConfig.HighlightSheriff)
                 then
                    color = Color3.fromRGB(255, 250, 0)
                    shouldHighlight = true
                end
                if shouldHighlight then
                    highlight = CreateHighlight(player)
                    if highlight then
                        highlight.FillColor = color
                        highlight.OutlineColor = color
                        highlight.Enabled = true
                    end
                elseif highlight then
                    highlight.Enabled = false
                end
            end
        end
    end
    function IsAlive(player)
        for name, data in pairs(roles) do
            if (player.Name == name) then
                return not data.Killed and not data.Dead
            end
        end
        return false
    end
    local function UpdateRoles()
        roles = ReplicatedStorage:FindFirstChild("GetPlayerData", true):InvokeServer()
        for name, data in pairs(roles) do
            if (data.Role == "Murderer") then
                Murder = name
            elseif (data.Role == "Sheriff") then
                Sheriff = name
            elseif (data.Role == "Hero") then
                Hero = name
            end
        end
    end
    Tabs.EspTab:Section({Title = gradient("Special ESP", Color3.fromHex("#b914fa"), Color3.fromHex("#7023c2"))})
    Tabs.EspTab:Toggle(
        {
            Title = gradient("Higlight Murder", Color3.fromHex("#e80909"), Color3.fromHex("#630404")),
            Default = false,
            Callback = function(state)
                ESPConfig.HighlightMurderer = state
                if not state then
                    UpdateHighlights()
                end
            end
        }
    )
    Tabs.EspTab:Toggle(
        {
            Title = gradient("Highlight Innocent", Color3.fromHex("#0ff707"), Color3.fromHex("#1e690c")),
            Default = false,
            Callback = function(state)
                ESPConfig.HighlightInnocent = state
                if not state then
                    UpdateHighlights()
                end
            end
        }
    )
    Tabs.EspTab:Toggle(
        {
            Title = gradient("Highlight Sheriff", Color3.fromHex("#001e80"), Color3.fromHex("#16f2d9")),
            Default = false,
            Callback = function(state)
                ESPConfig.HighlightSheriff = state
                if not state then
                    UpdateHighlights()
                end
            end
        }
    )
    local gunDropESPEnabled = false
    local gunDropHighlight = nil
    local mapPaths = {
        "ResearchFacility",
        "Hospital3",
        "MilBase",
        "House2",
        "Workplace",
        "Mansion2",
        "BioLab",
        "Hotel",
        "Factory",
        "Bank2",
        "PoliceStation"
    }
    local function createGunDropHighlight(gunDrop)
        if (gunDropESPEnabled and gunDrop and not gunDrop:FindFirstChild("GunDropHighlight")) then
            local highlight = Instance.new("Highlight")
            highlight.Name = "GunDropHighlight"
            highlight.FillColor = Color3.fromRGB(255, 215, 0)
            highlight.OutlineColor = Color3.fromRGB(255, 165, 0)
            highlight.Adornee = gunDrop
            highlight.Parent = gunDrop
        end
    end
    local function updateGunDropESP()
        for _, mapName in pairs(mapPaths) do
            local map = workspace:FindFirstChild(mapName)
            if map then
                local gunDrop = map:FindFirstChild("GunDrop")
                if (gunDrop and gunDrop:FindFirstChild("GunDropHighlight")) then
                    gunDrop.GunDropHighlight:Destroy()
                end
            end
        end
        if gunDropESPEnabled then
            for _, mapName in pairs(mapPaths) do
                local map = workspace:FindFirstChild(mapName)
                if map then
                    local gunDrop = map:FindFirstChild("GunDrop")
                    if gunDrop then
                        createGunDropHighlight(gunDrop)
                    end
                end
            end
        end
    end
    local function monitorGunDrops()
        for _, mapName in pairs(mapPaths) do
            local map = workspace:FindFirstChild(mapName)
            if map then
                map.ChildAdded:Connect(
                    function(child)
                        if (child.Name == "GunDrop") then
                            createGunDropHighlight(child)
                        end
                    end
                )
            end
        end
    end
    monitorGunDrops()
    Tabs.EspTab:Toggle(
        {
            Title = gradient("GunDrop Highlight", Color3.fromHex("#ffff00"), Color3.fromHex("#4f4f00")),
            Default = false,
            Callback = function(state)
                gunDropESPEnabled = state
                updateGunDropESP()
            end
        }
    )
    workspace.ChildAdded:Connect(
        function(child)
            if table.find(mapPaths, child.Name) then
                task.wait(2)
                updateGunDropESP()
            end
        end
    )
    RunService.RenderStepped:Connect(
        function()
            UpdateRoles()
            if (ESPConfig.HighlightMurderer or ESPConfig.HighlightInnocent or ESPConfig.HighlightSheriff) then
                UpdateHighlights()
            end
        end
    )
    Players.PlayerRemoving:Connect(
        function(player)
            if (player == LP) then
                RemoveAllHighlights()
            end
        end
    )
    Tabs.TeleportTab:Section({Title = gradient("Default TP", Color3.fromHex("#00448c"), Color3.fromHex("#0affd6"))})
    local teleportTarget = nil
    local teleportDropdown = nil
    local function updateTeleportPlayers()
        local playersList = {"Select Player"}
        for _, player in pairs(Players:GetPlayers()) do
            if (player ~= LocalPlayer) then
                table.insert(playersList, player.Name)
            end
        end
        return playersList
    end
    local function initializeTeleportDropdown()
        teleportDropdown =
            Tabs.TeleportTab:Dropdown(
            {Title = "Players", Values = updateTeleportPlayers(), Value = "Select Player", Callback = function(selected)
                    if (selected ~= "Select Player") then
                        teleportTarget = Players:FindFirstChild(selected)
                    else
                        teleportTarget = nil
                    end
                end}
        )
    end
    initializeTeleportDropdown()
    Players.PlayerAdded:Connect(
        function(player)
            task.wait(1)
            if teleportDropdown then
                teleportDropdown:Refresh(updateTeleportPlayers())
            end
        end
    )
    Players.PlayerRemoving:Connect(
        function(player)
            if teleportDropdown then
                teleportDropdown:Refresh(updateTeleportPlayers())
            end
        end
    )
    local function teleportToPlayer()
        if (teleportTarget and teleportTarget.Character) then
            local targetRoot = teleportTarget.Character:FindFirstChild("HumanoidRootPart")
            local localRoot = LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
            if (targetRoot and localRoot) then
                localRoot.CFrame = targetRoot.CFrame
                WindUI:Notify(
                    {
                        Title = "Teleportation",
                        Content = "Successfully teleported to " .. teleportTarget.Name,
                        Icon = "check-circle",
                        Duration = 3
                    }
                )
            end
        else
            WindUI:Notify(
                {Title = "DYHUB", Content = "Target not found or unavailable", Icon = "x-circle", Duration = 3}
            )
        end
    end
    Tabs.TeleportTab:Button({Title = "Teleport to player", Callback = teleportToPlayer})
    Tabs.TeleportTab:Button(
        {Title = "Update players list", Callback = function()
                teleportDropdown:Refresh(updateTeleportPlayers())
            end}
    )
    Tabs.TeleportTab:Section({Title = gradient("Special TP", Color3.fromHex("#b914fa"), Color3.fromHex("#7023c2"))})
    local function teleportToLobby()
        local lobby = workspace:FindFirstChild("Lobby")
        if not lobby then
            WindUI:Notify({Title = "Teleport", Content = "Lobby not found!", Icon = "x-circle", Duration = 2})
            return
        end
        local spawnPoint = lobby:FindFirstChild("SpawnPoint") or lobby:FindFirstChildOfClass("SpawnLocation")
        if not spawnPoint then
            spawnPoint = lobby:FindFirstChildWhichIsA("BasePart") or lobby
        end
        if (LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("HumanoidRootPart")) then
            LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(spawnPoint.Position + Vector3.new(0, 3, 0))
            WindUI:Notify({Title = "Teleport", Content = "Teleported to Lobby!", Icon = "check-circle", Duration = 2})
        end
    end
    Tabs.TeleportTab:Button({Title = "Teleport to Lobby", Callback = teleportToLobby})
    Tabs.TeleportTab:Button(
        {
            Title = "Teleport to Sheriff",
            Callback = function()
                UpdateRoles()
                if Sheriff then
                    local sheriffPlayer = Players:FindFirstChild(Sheriff)
                    if (sheriffPlayer and sheriffPlayer.Character) then
                        local targetRoot = sheriffPlayer.Character:FindFirstChild("HumanoidRootPart")
                        local localRoot = LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
                        if (targetRoot and localRoot) then
                            localRoot.CFrame = targetRoot.CFrame
                            WindUI:Notify(
                                {
                                    Title = "DYHUB",
                                    Content = "Successfully teleported to the sheriff: " .. Sheriff,
                                    Icon = "check-circle",
                                    Duration = 3
                                }
                            )
                        end
                    else
                        WindUI:Notify(
                            {
                                Title = "DYHUB",
                                Content = "Sheriff not found or unavailable",
                                Icon = "x-circle",
                                Duration = 3
                            }
                        )
                    end
                else
                    WindUI:Notify(
                        {
                            Title = "DYHUB",
                            Content = "Sheriff is not determined in the current match",
                            Icon = "x-circle",
                            Duration = 3
                        }
                    )
                end
            end
        }
    )
    Tabs.TeleportTab:Button(
        {
            Title = "Teleport to Murderer",
            Callback = function()
                UpdateRoles()
                if Murder then
                    local murderPlayer = Players:FindFirstChild(Murder)
                    if (murderPlayer and murderPlayer.Character) then
                        local targetRoot = murderPlayer.Character:FindFirstChild("HumanoidRootPart")
                        local localRoot = LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
                        if (targetRoot and localRoot) then
                            localRoot.CFrame = targetRoot.CFrame
                            WindUI:Notify(
                                {
                                    Title = "DYHUB",
                                    Content = "Successfully teleported to the Murder:" .. Murder,
                                    Icon = "check-circle",
                                    Duration = 3
                                }
                            )
                        end
                    else
                        WindUI:Notify(
                            {
                                Title = "DYHUB",
                                Content = "The Murder has not been found or is unavailable.",
                                Icon = "x-circle",
                                Duration = 3
                            }
                        )
                    end
                else
                    WindUI:Notify(
                        {
                            Title = "DYHUB",
                            Content = "The Murder is not determined in the current match.",
                            Icon = "x-circle",
                            Duration = 3
                        }
                    )
                end
            end
        }
    )
    Players.PlayerAdded:Connect(
        function()
            teleportDropdown:Refresh({updateTeleportPlayers()})
        end
    )
    Players.PlayerRemoving:Connect(
        function()
            teleportDropdown:Refresh({updateTeleportPlayers()})
        end
    )
    local roles = {}
    local Murder, Sheriff
    local isCameraLocked = false
    local isSpectating = false
    local lockedRole = nil
    local cameraConnection = nil
    local originalCameraType = Enum.CameraType.Custom
    local originalCameraSubject = nil
    function IsAlive(player)
        for name, data in pairs(roles) do
            if (player.Name == name) then
                return not data.Killed and not data.Dead
            end
        end
        return false
    end
    local function UpdateRoles()
        local success, result =
            pcall(
            function()
                return ReplicatedStorage:FindFirstChild("GetPlayerData", true):InvokeServer()
            end
        )
        if success then
            roles = result or {}
            Murder, Sheriff = nil, nil
            for name, data in pairs(roles) do
                if (data.Role == "Murderer") then
                    Murder = name
                elseif (data.Role == "Sheriff") then
                    Sheriff = name
                end
            end
        end
    end
    Tabs.AimbotTab:Section({Title = gradient("Default AimBot", Color3.fromHex("#00448c"), Color3.fromHex("#0affd6"))})
    RoleDropdown =
        Tabs.AimbotTab:Dropdown(
        {Title = "Target Role", Values = {"None", "Sheriff", "Murderer"}, Value = "None", Callback = function(selected)
                lockedRole = ((selected ~= "None") and selected) or nil
            end}
    )
    Tabs.AimbotTab:Toggle(
        {Title = "Spectate Mode", Default = false, Callback = function(state)
                isSpectating = state
                if state then
                    originalCameraType = CurrentCamera.CameraType
                    originalCameraSubject = CurrentCamera.CameraSubject
                    CurrentCamera.CameraType = Enum.CameraType.Scriptable
                else
                    CurrentCamera.CameraType = originalCameraType
                    CurrentCamera.CameraSubject = originalCameraSubject
                end
            end}
    )
    Tabs.AimbotTab:Toggle(
        {Title = "Lock Camera", Default = false, Callback = function(state)
                isCameraLocked = state
                if (not state and not isSpectating) then
                    CurrentCamera.CameraType = originalCameraType
                    CurrentCamera.CameraSubject = originalCameraSubject
                end
            end}
    )
    local function GetTargetPosition()
        if not lockedRole then
            return nil
        end
        local targetName = ((lockedRole == "Sheriff") and Sheriff) or Murder
        if not targetName then
            return nil
        end
        local player = Players:FindFirstChild(targetName)
        if (not player or not IsAlive(player)) then
            return nil
        end
        local character = player.Character
        if not character then
            return nil
        end
        local head = character:FindFirstChild("Head")
        return (head and head.Position) or nil
    end
    local function UpdateSpectate()
        if (not isSpectating or not lockedRole) then
            return
        end
        local targetPos = GetTargetPosition()
        if not targetPos then
            return
        end
        local offset = CFrame.new(0, 2, 8)
        local targetChar = Players:FindFirstChild(((lockedRole == "Sheriff") and Sheriff) or Murder).Character
        if targetChar then
            local root = targetChar:FindFirstChild("HumanoidRootPart")
            if root then
                CurrentCamera.CFrame = root.CFrame * offset
            end
        end
    end
    local function UpdateLockCamera()
        if (not isCameraLocked or not lockedRole) then
            return
        end
        local targetPos = GetTargetPosition()
        if not targetPos then
            return
        end
        local currentPos = CurrentCamera.CFrame.Position
        CurrentCamera.CFrame = CFrame.new(currentPos, targetPos)
    end
    local function Update()
        if isSpectating then
            UpdateSpectate()
        elseif isCameraLocked then
            UpdateLockCamera()
        end
    end
    local function AutoUpdate()
        while true do
            UpdateRoles()
            task.wait(3)
        end
    end
    coroutine.wrap(AutoUpdate)()
    cameraConnection = RunService.RenderStepped:Connect(Update)
    LocalPlayer.AncestryChanged:Connect(
        function()
            if (not LocalPlayer.Parent and cameraConnection) then
                cameraConnection:Disconnect()
                CurrentCamera.CameraType = originalCameraType
                CurrentCamera.CameraSubject = originalCameraSubject
            end
        end
    )
    UpdateRoles()
    Tabs.AimbotTab:Section(
        {Title = gradient("Silent Aimbot (On rework)", Color3.fromHex("#00448c"), Color3.fromHex("#0affd6"))}
    )
    local AutoFarm = {
        Enabled = false,
        Mode = "Teleport",
        TeleportDelay = 0,
        MoveSpeed = 50,
        WalkSpeed = 32,
        Connection = nil,
        CoinCheckInterval = 0.5,
        CoinContainers = {
            "Factory",
            "Hospital3",
            "MilBase",
            "House2",
            "Workplace",
            "Mansion2",
            "BioLab",
            "Hotel",
            "Bank2",
            "PoliceStation",
            "ResearchFacility",
            "Lobby"
        }
    }
    local function findNearestCoin()
        local closestCoin = nil
        local shortestDistance = math.huge
        local character = LocalPlayer.Character
        local humanoidRootPart = character and character:FindFirstChild("HumanoidRootPart")
        if not humanoidRootPart then
            return nil
        end
        for _, containerName in ipairs(AutoFarm.CoinContainers) do
            local container = workspace:FindFirstChild(containerName)
            if container then
                local coinContainer =
                    ((containerName == "Lobby") and container) or container:FindFirstChild("CoinContainer")
                if coinContainer then
                    for _, coin in ipairs(coinContainer:GetChildren()) do
                        if coin:IsA("BasePart") then
                            local distance = (humanoidRootPart.Position - coin.Position).Magnitude
                            if (distance < shortestDistance) then
                                shortestDistance = distance
                                closestCoin = coin
                            end
                        end
                    end
                end
            end
        end
        return closestCoin
    end
    local function teleportToCoin(coin)
        if (not coin or not LocalPlayer.Character) then
            return
        end
        local humanoidRootPart = LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
        if not humanoidRootPart then
            return
        end
        humanoidRootPart.CFrame = CFrame.new(coin.Position + Vector3.new(0, 3, 0))
        task.wait(AutoFarm.TeleportDelay)
    end
    local function smoothMoveToCoin(coin)
        if (not coin or not LocalPlayer.Character) then
            return
        end
        local humanoidRootPart = LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
        if not humanoidRootPart then
            return
        end
        local startTime = tick()
        local startPos = humanoidRootPart.Position
        local endPos = coin.Position + Vector3.new(0, 3, 0)
        local distance = (startPos - endPos).Magnitude
        local duration = distance / AutoFarm.MoveSpeed
        while ((tick() - startTime) < duration) and AutoFarm.Enabled do
            if (not coin or not coin.Parent) then
                break
            end
            local progress = math.min((tick() - startTime) / duration, 1)
            humanoidRootPart.CFrame = CFrame.new(startPos:Lerp(endPos, progress))
            task.wait()
        end
    end
    local function walkToCoin(coin)
        if (not coin or not LocalPlayer.Character) then
            return
        end
        local humanoid = LocalPlayer.Character:FindFirstChildOfClass("Humanoid")
        if not humanoid then
            return
        end
        humanoid.WalkSpeed = AutoFarm.WalkSpeed
        humanoid:MoveTo(coin.Position + Vector3.new(0, 0, 3))
        local startTime = tick()
        while AutoFarm.Enabled and (humanoid.MoveDirection.Magnitude > 0) and ((tick() - startTime) < 10) do
            task.wait(0.5)
        end
    end
    local function collectCoin(coin)
        if (not coin or not LocalPlayer.Character) then
            return
        end
        local humanoidRootPart = LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
        if not humanoidRootPart then
            return
        end
        firetouchinterest(humanoidRootPart, coin, 0)
        firetouchinterest(humanoidRootPart, coin, 1)
    end
    local function farmLoop()
        while AutoFarm.Enabled do
            local coin = findNearestCoin()
            if coin then
                if (AutoFarm.Mode == "Teleport") then
                    teleportToCoin(coin)
                elseif (AutoFarm.Mode == "Smooth") then
                    smoothMoveToCoin(coin)
                else
                    walkToCoin(coin)
                end
                collectCoin(coin)
            else
                WindUI:Notify(
                    {Title = "AutoFarm", Content = "No coins found nearby!", Icon = "alert-circle", Duration = 2}
                )
                task.wait(2)
            end
            task.wait(AutoFarm.CoinCheckInterval)
        end
    end
    Tabs.AutoFarm:Section({Title = gradient("Coin Farming", Color3.fromHex("#FFD700"), Color3.fromHex("#FFA500"))})
    Tabs.AutoFarm:Dropdown(
        {Title = "Movement Mode", Values = {"Teleport", "Smooth", "Walk"}, Value = "Teleport", Callback = function(mode)
                AutoFarm.Mode = mode
                WindUI:Notify(
                    {Title = "AutoFarm", Content = "Mode set to: " .. mode, Icon = "check-circle", Duration = 2}
                )
            end}
    )
    Tabs.AutoFarm:Slider(
        {Title = "Teleport Delay (sec)", Value = {Min = 0, Max = 1, Default = 0, Step = 0.1}, Callback = function(value)
                AutoFarm.TeleportDelay = value
            end}
    )
    Tabs.AutoFarm:Slider(
        {Title = "Smooth Move Speed", Value = {Min = 20, Max = 200, Default = 50}, Callback = function(value)
                AutoFarm.MoveSpeed = value
            end}
    )
    Tabs.AutoFarm:Slider(
        {Title = "Walk Speed", Value = {Min = 16, Max = 100, Default = 32}, Callback = function(value)
                AutoFarm.WalkSpeed = value
            end}
    )
    Tabs.AutoFarm:Slider(
        {
            Title = "Check Interval (sec)",
            Step = 0.1,
            Value = {Min = 0.1, Max = 2, Default = 0.5},
            Callback = function(value)
                AutoFarm.CoinCheckInterval = value
            end
        }
    )
    Tabs.AutoFarm:Toggle(
        {
            Title = "Enable AutoFarm",
            Default = false,
            Callback = function(state)
                AutoFarm.Enabled = state
                if state then
                    AutoFarm.Connection = task.spawn(farmLoop)
                    WindUI:Notify(
                        {
                            Title = "AutoFarm",
                            Content = "Started farming nearest coins!",
                            Icon = "check-circle",
                            Duration = 2
                        }
                    )
                else
                    if AutoFarm.Connection then
                        task.cancel(AutoFarm.Connection)
                    end
                    WindUI:Notify(
                        {Title = "AutoFarm", Content = "Stopped farming coins", Icon = "x-circle", Duration = 2}
                    )
                end
            end
        }
    )
    local GunSystem = {
        AutoGrabEnabled = false,
        NotifyGunDrop = true,
        GunDropCheckInterval = 1,
        ActiveGunDrops = {},
        GunDropHighlights = {}
    }
    local mapPaths = {
        "ResearchFacility",
        "Hospital3",
        "MilBase",
        "House2",
        "Workplace",
        "Mansion2",
        "BioLab",
        "Hotel",
        "Factory",
        "Bank2",
        "PoliceStation"
    }
    local function TeleportToMurderer(murderer)
        local targetRoot = murderer.Character:FindFirstChild("HumanoidRootPart")
        local localRoot = LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
        if (targetRoot and localRoot) then
            localRoot.CFrame = targetRoot.CFrame * CFrame.new(0, 0, -5)
            task.wait(0.3)
            return true
        end
        return false
    end
    local function ScanForGunDrops()
        GunSystem.ActiveGunDrops = {}
        for _, mapName in ipairs(mapPaths) do
            local map = workspace:FindFirstChild(mapName)
            if map then
                local gunDrop = map:FindFirstChild("GunDrop")
                if gunDrop then
                    table.insert(GunSystem.ActiveGunDrops, gunDrop)
                end
            end
        end
        local rootGunDrop = workspace:FindFirstChild("GunDrop")
        if rootGunDrop then
            table.insert(GunSystem.ActiveGunDrops, rootGunDrop)
        end
    end
    local function EquipGun()
        if (LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("Gun")) then
            return true
        end
        local gun = LocalPlayer.Backpack:FindFirstChild("Gun")
        if gun then
            gun.Parent = LocalPlayer.Character
            task.wait(0.1)
            return LocalPlayer.Character:FindFirstChild("Gun") ~= nil
        end
        return false
    end
    local function GrabGun(gunDrop)
        if not gunDrop then
            ScanForGunDrops()
            if (#GunSystem.ActiveGunDrops == 0) then
                WindUI:Notify(
                    {Title = "Gun System", Content = "No guns available on the map", Icon = "x-circle", Duration = 3}
                )
                return false
            end
            local nearestGun = nil
            local minDistance = math.huge
            local character = LocalPlayer.Character
            local humanoidRootPart = character and character:FindFirstChild("HumanoidRootPart")
            if humanoidRootPart then
                for _, drop in ipairs(GunSystem.ActiveGunDrops) do
                    local distance = (humanoidRootPart.Position - drop.Position).Magnitude
                    if (distance < minDistance) then
                        nearestGun = drop
                        minDistance = distance
                    end
                end
            end
            gunDrop = nearestGun
        end
        if (gunDrop and LocalPlayer.Character) then
            local humanoidRootPart = LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
            if humanoidRootPart then
                humanoidRootPart.CFrame = gunDrop.CFrame
                task.wait(0.3)
                local prompt = gunDrop:FindFirstChildOfClass("ProximityPrompt")
                if prompt then
                    fireproximityprompt(prompt)
                    WindUI:Notify(
                        {
                            Title = "Gun System",
                            Content = "Successfully grabbed the gun!",
                            Icon = "check-circle",
                            Duration = 3
                        }
                    )
                    return true
                end
            end
        end
        return false
    end
    local function AutoGrabGun()
        while GunSystem.AutoGrabEnabled do
            ScanForGunDrops()
            if ((#GunSystem.ActiveGunDrops > 0) and LocalPlayer.Character) then
                local humanoidRootPart = LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
                if humanoidRootPart then
                    local nearestGun = nil
                    local minDistance = math.huge
                    for _, gunDrop in ipairs(GunSystem.ActiveGunDrops) do
                        local distance = (humanoidRootPart.Position - gunDrop.Position).Magnitude
                        if (distance < minDistance) then
                            nearestGun = gunDrop
                            minDistance = distance
                        end
                    end
                    if nearestGun then
                        humanoidRootPart.CFrame = nearestGun.CFrame
                        task.wait(0.3)
                        local prompt = nearestGun:FindFirstChildOfClass("ProximityPrompt")
                        if prompt then
                            fireproximityprompt(prompt)
                            task.wait(1)
                        end
                    end
                end
            end
            task.wait(GunSystem.GunDropCheckInterval)
        end
    end
    local function GetMurderer()
        local roles = ReplicatedStorage:FindFirstChild("GetPlayerData"):InvokeServer()
        for playerName, data in pairs(roles) do
            if (data.Role == "Murderer") then
                return Players:FindFirstChild(playerName)
            end
        end
    end
    local Players = game:GetService("Players")
    local LocalPlayer = Players.LocalPlayer
    local ReplicatedStorage = game:GetService("ReplicatedStorage")
    local function GrabAndShootMurderer()
        if not (LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("Gun")) then
            if not GrabGun() then
                WindUI:Notify({Title = "Gun System", Content = "Failed to get gun!", Icon = "x-circle", Duration = 3})
                return
            end
            task.wait(0.1)
        end
        if not EquipGun() then
            WindUI:Notify({Title = "Gun System", Content = "Failed to equip gun!", Icon = "x-circle", Duration = 3})
            return
        end
        local roles = ReplicatedStorage:FindFirstChild("GetPlayerData", true):InvokeServer()
        local murderer = nil
        for name, data in pairs(roles) do
            if (data.Role == "Murderer") then
                murderer = Players:FindFirstChild(name)
                break
            end
        end
        if (not murderer or not murderer.Character) then
            WindUI:Notify({Title = "Gun System", Content = "Murderer not found!", Icon = "x-circle", Duration = 3})
            return
        end
        local targetRoot = murderer.Character:FindFirstChild("HumanoidRootPart")
        local localRoot = LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
        if (targetRoot and localRoot) then
            localRoot.CFrame = targetRoot.CFrame * CFrame.new(0, 0, -4)
            task.wait(0.1)
        end
        local gun = LocalPlayer.Character:FindFirstChild("Gun")
        if not gun then
            WindUI:Notify({Title = "Gun System", Content = "Gun not equipped!", Icon = "x-circle", Duration = 3})
            return
        end
        local targetPart = murderer.Character:FindFirstChild("HumanoidRootPart")
        if not targetPart then
            return
        end
        local args = {[1] = 1, [2] = targetPart.Position, [3] = "AH2"}
        if (gun:FindFirstChild("KnifeLocal") and gun.KnifeLocal:FindFirstChild("CreateBeam")) then
            gun.KnifeLocal.CreateBeam.RemoteFunction:InvokeServer(unpack(args))
            WindUI:Notify(
                {Title = "Gun System", Content = "Successfully shot the murderer!", Icon = "check-circle", Duration = 3}
            )
        end
    end
    local Players = game:GetService("Players")
    local LocalPlayer = Players.LocalPlayer
    local ReplicatedStorage = game:GetService("ReplicatedStorage")
    local gunDropESPEnabled = true
    local notifiedGunDrops = {}
    local mapGunDrops = {
        "ResearchFacility",
        "Hospital3",
        "MilBase",
        "House2",
        "Workplace",
        "Mansion2",
        "BioLab",
        "Hotel",
        "Factory",
        "Bank2",
        "PoliceStation"
    }
    local function checkForGunDrops()
        for _, mapName in ipairs(mapGunDrops) do
            local map = workspace:FindFirstChild(mapName)
            if map then
                local gunDrop = map:FindFirstChild("GunDrop")
                if (gunDrop and not notifiedGunDrops[gunDrop]) then
                    if gunDropESPEnabled then
                        WindUI:Notify(
                            {
                                Title = "Gun Drop Spawned",
                                Content = "A gun has appeared on the map: " .. mapName,
                                Icon = "alert-circle",
                                Duration = 5
                            }
                        )
                    end
                    notifiedGunDrops[gunDrop] = true
                end
            end
        end
    end
    local function setupGunDropMonitoring()
        for _, mapName in ipairs(mapGunDrops) do
            local map = workspace:FindFirstChild(mapName)
            if map then
                if map:FindFirstChild("GunDrop") then
                    checkForGunDrops()
                end
                map.ChildAdded:Connect(
                    function(child)
                        if (child.Name == "GunDrop") then
                            task.wait(0.5)
                            checkForGunDrops()
                        end
                    end
                )
            end
        end
    end
    local function setupGunDropRemovalTracking()
        for _, mapName in ipairs(mapGunDrops) do
            local map = workspace:FindFirstChild(mapName)
            if map then
                map.ChildRemoved:Connect(
                    function(child)
                        if ((child.Name == "GunDrop") and notifiedGunDrops[child]) then
                            notifiedGunDrops[child] = nil
                        end
                    end
                )
            end
        end
    end
    setupGunDropMonitoring()
    setupGunDropRemovalTracking()
    workspace.ChildAdded:Connect(
        function(child)
            if table.find(mapGunDrops, child.Name) then
                task.wait(2)
                checkForGunDrops()
            end
        end
    )
    Tabs.InnocentTab:Toggle(
        {
            Title = "Notify GunDrop",
            Default = true,
            Callback = function(state)
                gunDropESPEnabled = state
                if state then
                    task.spawn(
                        function()
                            task.wait(1)
                            checkForGunDrops()
                        end
                    )
                end
            end
        }
    )
    Tabs.InnocentTab:Button(
        {Title = "Grab Gun", Callback = function()
                GrabGun()
            end}
    )
    Tabs.InnocentTab:Toggle(
        {Title = "Auto Grab Gun", Default = false, Callback = function(state)
                GunSystem.AutoGrabEnabled = state
                if state then
                    coroutine.wrap(AutoGrabGun)()
                    WindUI:Notify(
                        {Title = "Gun System", Content = "Auto Grab Gun enabled!", Icon = "check-circle", Duration = 3}
                    )
                else
                    WindUI:Notify(
                        {Title = "Gun System", Content = "Auto Grab Gun disabled", Icon = "check-circle", Duration = 3}
                    )
                end
            end}
    )
    Tabs.InnocentTab:Button(
        {Title = "Grab Gun & Shoot Murderer", Callback = function()
                GrabAndShootMurderer()
            end}
    )
    task.spawn(
        function()
            if not LocalPlayer.Character then
                LocalPlayer.CharacterAdded:Wait()
            end
            ScanForGunDrops()
            if GunSystem.AutoGrabEnabled then
                coroutine.wrap(AutoGrabGun)()
            end
        end
    )

    Tabs.MainTab:Section({
    Title = gradient("Instead Unlock Emote", Color3.fromHex("#ffffff"), Color3.fromHex("#ff0000"))
})

Tabs.MainTab:Button({
    Title = "Dupe Emote All",
    Description = "Unlock all emotes by pressing this button.",
    Callback = function()
        local player = game.Players.LocalPlayer
        local replicatedStorage = game:GetService("ReplicatedStorage")
        local playerGui = player:FindFirstChild("PlayerGui")
        if not playerGui then
            warn("PlayerGui not found")
            return
        end

        local mainGui = playerGui:FindFirstChild("MainGUI")
        if not mainGui then
            warn("MainGUI not found")
            return
        end

        local gameFrame = mainGui:FindFirstChild("Game")
        if not gameFrame then
            warn("Game frame not found")
            return
        end

        local emoteFrame = gameFrame:FindFirstChild("Emotes")
        if not emoteFrame then
            warn("Emote frame not found")
            return
        end

        local modulesFolder = replicatedStorage:FindFirstChild("Modules")
        if not modulesFolder then
            warn("Modules folder not found in ReplicatedStorage")
            return
        end

        local emoteModuleScript = modulesFolder:FindFirstChild("EmoteModule")
        if not emoteModuleScript then
            warn("EmoteModule not found")
            return
        end

        local success, emoteModule = pcall(require, emoteModuleScript)
        if not success then
            warn("Failed to require EmoteModule:", emoteModule)
            return
        end

        if emoteModule and typeof(emoteModule.GeneratePage) == "function" then
            emoteModule.GeneratePage(
                {"headless", "zombie", "zen", "ninja", "floss", "dab", "sit"},
                emoteFrame,
                "DYHUB EMOTES"
            )
            print("Emotes unlocked successfully!")
        else
            warn("GeneratePage function not found in EmoteModule")
        end
    end
})
    
    local killActive = false
    local attackDelay = 0.5
    local targetRoles = {"Sheriff", "Hero", "Innocent"}
    local function getPlayerRole(player)
        local roles = ReplicatedStorage:FindFirstChild("GetPlayerData", true):InvokeServer()
        if (roles and roles[player.Name]) then
            return roles[player.Name].Role
        end
        return nil
    end
    local function equipKnife()
        local character = LocalPlayer.Character
        if not character then
            return false
        end
        if character:FindFirstChild("Knife") then
            return true
        end
        local knife = LocalPlayer.Backpack:FindFirstChild("Knife")
        if knife then
            knife.Parent = character
            return true
        end
        return false
    end
    local function getNearestTarget()
        local targets = {}
        local roles = ReplicatedStorage:FindFirstChild("GetPlayerData", true):InvokeServer()
        local localRoot = LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
        if not localRoot then
            return nil
        end
        for _, player in ipairs(Players:GetPlayers()) do
            if ((player ~= LocalPlayer) and player.Character) then
                local role = getPlayerRole(player)
                local humanoid = player.Character:FindFirstChild("Humanoid")
                local targetRoot = player.Character:FindFirstChild("HumanoidRootPart")
                if (role and humanoid and (humanoid.Health > 0) and targetRoot and table.find(targetRoles, role)) then
                    table.insert(
                        targets,
                        {Player = player, Distance = (localRoot.Position - targetRoot.Position).Magnitude}
                    )
                end
            end
        end
        table.sort(
            targets,
            function(a, b)
                return a.Distance < b.Distance
            end
        )
        return (targets[1] and targets[1].Player) or nil
    end
    local function attackTarget(target)
        if (not target or not target.Character) then
            return false
        end
        local humanoid = target.Character:FindFirstChild("Humanoid")
        if (not humanoid or (humanoid.Health <= 0)) then
            return false
        end
        if not equipKnife() then
            WindUI:Notify({Title = "Kill Targets", Content = "No knife found!", Icon = "x-circle", Duration = 2})
            return false
        end
        local targetRoot = target.Character:FindFirstChild("HumanoidRootPart")
        local localRoot = LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
        if (targetRoot and localRoot) then
            localRoot.CFrame =
                CFrame.new(
                targetRoot.Position + ((localRoot.Position - targetRoot.Position).Unit * 2),
                targetRoot.Position
            )
        end
        local knife = LocalPlayer.Character:FindFirstChild("Knife")
        if (knife and knife:FindFirstChild("Stab")) then
            for i = 1, 3 do
                knife.Stab:FireServer("Down")
            end
            return true
        end
        return false
    end
    local function killTargets()
        if killActive then
            return
        end
        killActive = true
        WindUI:Notify(
            {
                Title = "Kill Targets",
                Content = "Starting attack on nearest targets...",
                Icon = "alert-circle",
                Duration = 2
            }
        )
        local function attackSequence()
            while killActive do
                local target = getNearestTarget()
                if not target then
                    WindUI:Notify(
                        {
                            Title = "Kill Targets",
                            Content = "No valid targets found!",
                            Icon = "check-circle",
                            Duration = 3
                        }
                    )
                    killActive = false
                    break
                end
                if attackTarget(target) then
                    WindUI:Notify(
                        {
                            Title = "Kill Targets",
                            Content = "Attacked " .. target.Name,
                            Icon = "check-circle",
                            Duration = 1
                        }
                    )
                end
                task.wait(attackDelay)
            end
        end
        task.spawn(attackSequence)
    end
    local function stopKilling()
        killActive = false
        WindUI:Notify({Title = "Kill Targets", Content = "Attack sequence stopped", Icon = "x-circle", Duration = 2})
    end
    Tabs.MurderTab:Section({Title = gradient("Kill Functions", Color3.fromHex("#e80909"), Color3.fromHex("#630404"))})
    Tabs.MurderTab:Toggle(
        {Title = "Kill All", Default = false, Callback = function(state)
                if state then
                    killTargets()
                else
                    stopKilling()
                end
            end}
    )
    Tabs.MurderTab:Slider(
        {
            Title = "Attack Delay",
            Step = 0.1,
            Value = {Min = 0.1, Max = 2, Default = 0.5},
            Callback = function(value)
                attackDelay = value
                WindUI:Notify(
                    {
                        Title = "Kill Targets",
                        Content = "Delay set to " .. value .. "s",
                        Icon = "check-circle",
                        Duration = 2
                    }
                )
            end
        }
    )
    Tabs.MurderTab:Button(
        {Title = "Equip Knife", Callback = function()
                if equipKnife() then
                    WindUI:Notify({Title = "Knife", Content = "Knife equipped!", Icon = "check-circle", Duration = 2})
                else
                    WindUI:Notify({Title = "Knife", Content = "No knife found!", Icon = "x-circle", Duration = 2})
                end
            end}
    )
    local shotButton = nil
    local shotButtonFrame = nil
    local shotButtonActive = false
    local shotType = "Default"
    local buttonSize = 50
    local isDragging = false
    local function CreateShotButton()
        if shotButton then
            return
        end
        local screenGui = game:GetService("CoreGui"):FindFirstChild("WindUI_SheriffGui") or Instance.new("ScreenGui")
        screenGui.Name = "WindUI_SheriffGui"
        screenGui.Parent = game:GetService("CoreGui")
        screenGui.ResetOnSpawn = false
        screenGui.DisplayOrder = 999
        screenGui.IgnoreGuiInset = true
        shotButtonFrame = Instance.new("Frame")
        shotButtonFrame.Name = "ShotButtonFrame"
        shotButtonFrame.Size = UDim2.new(0, buttonSize, 0, buttonSize)
        shotButtonFrame.Position = UDim2.new(1, -buttonSize - 20, 0.5, -buttonSize / 2)
        shotButtonFrame.AnchorPoint = Vector2.new(1, 0.5)
        shotButtonFrame.BackgroundTransparency = 1
        shotButtonFrame.ZIndex = 100
        shotButton = Instance.new("TextButton")
        shotButton.Name = "SheriffShotButton"
        shotButton.Size = UDim2.new(1, 0, 1, 0)
        shotButton.BackgroundColor3 = Color3.fromRGB(120, 120, 120)
        shotButton.BackgroundTransparency = 0.5
        shotButton.TextColor3 = Color3.fromRGB(255, 255, 255)
        shotButton.Text = "SHOT"
        shotButton.TextSize = 14
        shotButton.Font = Enum.Font.GothamBold
        shotButton.BorderSizePixel = 0
        shotButton.ZIndex = 101
        shotButton.AutoButtonColor = false
        shotButton.TextScaled = true
        local stroke = Instance.new("UIStroke")
        stroke.Color = Color3.fromRGB(0, 40, 150)
        stroke.Thickness = 2
        stroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
        stroke.Transparency = 0.3
        stroke.Parent = shotButton
        local corner = Instance.new("UICorner")
        corner.CornerRadius = UDim.new(0.3, 0)
        corner.Parent = shotButton
        local shadow = Instance.new("ImageLabel")
        shadow.Name = "Shadow"
        shadow.Size = UDim2.new(1, 10, 1, 10)
        shadow.Position = UDim2.new(0.5, 0, 0.5, 0)
        shadow.AnchorPoint = Vector2.new(0.5, 0.5)
        shadow.BackgroundTransparency = 1
        shadow.Image = "rbxassetid://1316045217"
        shadow.ImageColor3 = Color3.new(0, 0, 0)
        shadow.ImageTransparency = 0.85
        shadow.ScaleType = Enum.ScaleType.Slice
        shadow.SliceCenter = Rect.new(10, 10, 118, 118)
        shadow.ZIndex = 100
        shadow.Parent = shotButton
        local function animatePress()
            local tweenService = game:GetService("TweenService")
            local pressDown =
                tweenService:Create(
                shotButton,
                TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
                {
                    Size = UDim2.new(0.9, 0, 0.9, 0),
                    BackgroundColor3 = Color3.fromRGB(70, 70, 70),
                    TextColor3 = Color3.fromRGB(200, 200, 255)
                }
            )
            local pressUp =
                tweenService:Create(
                shotButton,
                TweenInfo.new(0.2, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out),
                {
                    Size = UDim2.new(1, 0, 1, 0),
                    BackgroundColor3 = Color3.fromRGB(100, 100, 100),
                    TextColor3 = Color3.fromRGB(255, 255, 255)
                }
            )
            pressDown:Play()
            pressDown.Completed:Wait()
            pressUp:Play()
        end
        shotButton.MouseButton1Click:Connect(
            function()
                animatePress()
                if
                    (not LocalPlayer.Character or not LocalPlayer.Character:FindFirstChild("Humanoid") or
                        (LocalPlayer.Character.Humanoid.Health <= 0))
                 then
                    return
                end
                local success, roles =
                    pcall(
                    function()
                        return ReplicatedStorage:FindFirstChild("GetPlayerData", true):InvokeServer()
                    end
                )
                if (not success or not roles) then
                    return
                end
                local murderer = nil
                for name, data in pairs(roles) do
                    if (data.Role == "Murderer") then
                        murderer = Players:FindFirstChild(name)
                        break
                    end
                end
                if
                    (not murderer or not murderer.Character or not murderer.Character:FindFirstChild("Humanoid") or
                        (murderer.Character.Humanoid.Health <= 0))
                 then
                    return
                end
                local gun = LocalPlayer.Character:FindFirstChild("Gun") or LocalPlayer.Backpack:FindFirstChild("Gun")
                if ((shotType == "Default") and not gun) then
                    return
                end
                if (gun and not LocalPlayer.Character:FindFirstChild("Gun")) then
                    gun.Parent = LocalPlayer.Character
                end
                if (shotType == "Teleport") then
                    local targetRoot = murderer.Character:FindFirstChild("HumanoidRootPart")
                    local localRoot = LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
                    if (targetRoot and localRoot) then
                        localRoot.CFrame = targetRoot.CFrame * CFrame.new(0, 0, -4)
                    end
                end
                if (gun and not LocalPlayer.Character:FindFirstChild("Gun")) then
                    gun.Parent = LocalPlayer.Character
                end
                gun = LocalPlayer.Character:FindFirstChild("Gun")
                if (gun and gun:FindFirstChild("KnifeLocal")) then
                    local targetPart = murderer.Character:FindFirstChild("HumanoidRootPart")
                    if targetPart then
                        local args = {[1] = 10, [2] = targetPart.Position, [3] = "AH2"}
                        gun.KnifeLocal.CreateBeam.RemoteFunction:InvokeServer(unpack(args))
                    end
                end
            end
        )
        local dragInput
        local dragStart
        local startPos
        local function updateInput(input)
            local delta = input.Position - dragStart
            local newPos =
                UDim2.new(startPos.X.Scale, startPos.X.Offset + delta.X, startPos.Y.Scale, startPos.Y.Offset + delta.Y)
            local guiSize = game:GetService("CoreGui").AbsoluteSize
            newPos =
                UDim2.new(
                math.clamp(newPos.X.Scale, 0, 1),
                math.clamp(newPos.X.Offset, 0, guiSize.X - buttonSize),
                math.clamp(newPos.Y.Scale, 0, 1),
                math.clamp(newPos.Y.Offset, 0, guiSize.Y - buttonSize)
            )
            shotButtonFrame.Position = newPos
        end
        shotButton.InputBegan:Connect(
            function(input)
                if (input.UserInputType == Enum.UserInputType.MouseButton1) then
                    isDragging = true
                    dragStart = input.Position
                    startPos = shotButtonFrame.Position
                    animatePress()
                    input.Changed:Connect(
                        function()
                            if (input.UserInputState == Enum.UserInputState.End) then
                                isDragging = false
                            end
                        end
                    )
                end
            end
        )
        shotButton.InputChanged:Connect(
            function(input)
                if ((input.UserInputType == Enum.UserInputType.MouseMovement) and isDragging) then
                    updateInput(input)
                end
            end
        )
        shotButton.Parent = shotButtonFrame
        shotButtonFrame.Parent = screenGui
        shotButtonActive = true
        WindUI:Notify(
            {Title = "Sheriff System", Content = "Shot button activated", Icon = "check-circle", Duration = 3}
        )
    end
    local function RemoveShotButton()
        if not shotButton then
            return
        end
        if shotButton then
            shotButton:Destroy()
            shotButton = nil
        end
        if shotButtonFrame then
            shotButtonFrame:Destroy()
            shotButtonFrame = nil
        end
        local screenGui = game:GetService("CoreGui"):FindFirstChild("WindUI_SheriffGui")
        if screenGui then
            screenGui:Destroy()
        end
        shotButtonActive = false
        WindUI:Notify({Title = "Shot Button", Content = "Deactivated", Icon = "check-circle", Duration = 3})
    end
    Tabs.SheriffTab:Section({Title = gradient("Shot functions", Color3.fromHex("#001e80"), Color3.fromHex("#16f2d9"))})
    Tabs.SheriffTab:Dropdown(
        {
            Title = "Shot Type",
            Values = {"Default", "Teleport"},
            Value = "Default",
            Callback = function(selectedType)
                shotType = selectedType
                WindUI:Notify(
                    {
                        Title = "Sheriff System",
                        Content = "Shot Type: " .. selectedType,
                        Icon = "check-circle",
                        Duration = 3
                    }
                )
            end
        }
    )
    Tabs.SheriffTab:Button(
        {Title = "Shoot murderer", Callback = function()
                ShootMurderer()
            end}
    )
    Tabs.SheriffTab:Section({Title = gradient("Shot Button", Color3.fromHex("#001e80"), Color3.fromHex("#16f2d9"))})
    Tabs.SheriffTab:Button(
        {Title = "Toggle Shot Button", Callback = function()
                if shotButtonActive then
                    RemoveShotButton()
                else
                    CreateShotButton()
                end
            end}
    )
    Tabs.SheriffTab:Slider(
        {
            Title = "Button Size",
            Step = 1,
            Value = {Min = 10, Max = 100, Default = 50},
            Callback = function(size)
                buttonSize = size
                if shotButtonActive then
                    local currentPos =
                        (shotButtonFrame and shotButtonFrame.Position) or
                        UDim2.new(1, -buttonSize - 20, 0.5, -buttonSize / 2)
                    RemoveShotButton()
                    CreateShotButton()
                    if shotButtonFrame then
                        shotButtonFrame.Position = currentPos
                    end
                end
                WindUI:Notify(
                    {Title = "Sheriff System", Content = "Size: " .. size, Icon = "check-circle", Duration = 3}
                )
            end
        }
    )
    local function ShootMurderer()
        if
            (not LocalPlayer.Character or not LocalPlayer.Character:FindFirstChild("Humanoid") or
                (LocalPlayer.Character.Humanoid.Health <= 0))
         then
            return
        end
        local success, roles =
            pcall(
            function()
                return ReplicatedStorage:FindFirstChild("GetPlayerData", true):InvokeServer()
            end
        )
        if (not success or not roles) then
            return
        end
        local murderer = nil
        for name, data in pairs(roles) do
            if (data.Role == "Murderer") then
                murderer = Players:FindFirstChild(name)
                break
            end
        end
        if
            (not murderer or not murderer.Character or not murderer.Character:FindFirstChild("Humanoid") or
                (murderer.Character.Humanoid.Health <= 0))
         then
            return
        end
        local gun = LocalPlayer.Character:FindFirstChild("Gun") or LocalPlayer.Backpack:FindFirstChild("Gun")
        if ((shotType == "Default") and not gun) then
            return
        end
        if (gun and not LocalPlayer.Character:FindFirstChild("Gun")) then
            gun.Parent = LocalPlayer.Character
        end
        if (shotType == "Teleport") then
            local targetRoot = murderer.Character:FindFirstChild("HumanoidRootPart")
            local localRoot = LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
            if (targetRoot and localRoot) then
                localRoot.CFrame = targetRoot.CFrame * CFrame.new(0, 0, -4)
            end
        end
        if (gun and not LocalPlayer.Character:FindFirstChild("Gun")) then
            gun.Parent = LocalPlayer.Character
        end
        gun = LocalPlayer.Character:FindFirstChild("Gun")
        if (gun and gun:FindFirstChild("KnifeLocal")) then
            local targetPart = murderer.Character:FindFirstChild("HumanoidRootPart")
            if targetPart then
                local args = {[1] = 1, [2] = targetPart.Position, [3] = "AH2"}
                gun.KnifeLocal.CreateBeam.RemoteFunction:InvokeServer(unpack(args))
            end
        end
    end
    local Settings = {
        Hitbox = {Enabled = false, Size = 5, Color = Color3.new(1, 0, 0), Adornments = {}, Connections = {}},
        Noclip = {Enabled = false, Connection = nil},
        AntiAFK = {Enabled = false, Connection = nil}
    }
    local function ToggleNoclip(state)
        if state then
            Settings.Noclip.Connection =
                RunService.Stepped:Connect(
                function()
                    local chr = LocalPlayer.Character
                    if chr then
                        for _, part in pairs(chr:GetDescendants()) do
                            if part:IsA("BasePart") then
                                part.CanCollide = false
                            end
                        end
                    end
                end
            )
        elseif Settings.Noclip.Connection then
            Settings.Noclip.Connection:Disconnect()
        end
    end
    local function UpdateHitboxes()
        for _, plr in pairs(Players:GetPlayers()) do
            if (plr ~= LocalPlayer) then
                local chr = plr.Character
                local box = Settings.Hitbox.Adornments[plr]
                if (chr and Settings.Hitbox.Enabled) then
                    local root = chr:FindFirstChild("HumanoidRootPart")
                    if root then
                        if not box then
                            box = Instance.new("BoxHandleAdornment")
                            box.Adornee = root
                            box.Size = Vector3.new(Settings.Hitbox.Size, Settings.Hitbox.Size, Settings.Hitbox.Size)
                            box.Color3 = Settings.Hitbox.Color
                            box.Transparency = 0.4
                            box.ZIndex = 10
                            box.Parent = root
                            Settings.Hitbox.Adornments[plr] = box
                        else
                            box.Size = Vector3.new(Settings.Hitbox.Size, Settings.Hitbox.Size, Settings.Hitbox.Size)
                            box.Color3 = Settings.Hitbox.Color
                        end
                    end
                elseif box then
                    box:Destroy()
                    Settings.Hitbox.Adornments[plr] = nil
                end
            end
        end
    end
    local function ToggleAntiAFK(state)
        if state then
            Settings.AntiAFK.Connection =
                RunService.Heartbeat:Connect(
                function()
                    pcall(
                        function()
                            local vu = game:GetService("VirtualUser")
                            vu:CaptureController()
                            vu:ClickButton2(Vector2.new())
                        end
                    )
                end
            )
        elseif Settings.AntiAFK.Connection then
            Settings.AntiAFK.Connection:Disconnect()
        end
    end
    Tabs.SettingsTab:Section({Title = gradient("Hitboxes", Color3.fromHex("#ff0000"), Color3.fromHex("#ff8800"))})
    Tabs.SettingsTab:Toggle(
        {Title = "Hitboxes", Callback = function(state)
                Settings.Hitbox.Enabled = state
                if state then
                    RunService.Heartbeat:Connect(UpdateHitboxes)
                else
                    for _, box in pairs(Settings.Hitbox.Adornments) do
                        if box then
                            box:Destroy()
                        end
                    end
                    Settings.Hitbox.Adornments = {}
                end
            end}
    )
    Tabs.SettingsTab:Slider(
        {Title = "Hitbox size", Value = {Min = 1, Max = 10, Default = 5}, Callback = function(val)
                Settings.Hitbox.Size = val
                UpdateHitboxes()
            end}
    )
    Tabs.SettingsTab:Colorpicker(
        {Title = "Hitbox color", Default = Color3.new(1, 0, 0), Callback = function(col)
                Settings.Hitbox.Color = col
                UpdateHitboxes()
            end}
    )
    Tabs.SettingsTab:Section(
        {Title = gradient("Character Functions", Color3.fromHex("#00eaff"), Color3.fromHex("#002a2e"))}
    )
    Tabs.SettingsTab:Toggle(
        {Title = "Anti-AFK", Callback = function(state)
                Settings.AntiAFK.Enabled = state
                ToggleAntiAFK(state)
            end}
    )
    Tabs.SettingsTab:Toggle(
        {Title = "NoClip", Callback = function(state)
                Settings.Noclip.Enabled = state
                ToggleNoclip(state)
            end}
    )
    Tabs.SettingsTab:Section({Title = gradient("Auto Execute", Color3.fromHex("#00ff40"), Color3.fromHex("#88f2a2"))})
    local AutoInject = {
        Enabled = false,
        ScriptURL = "https://raw.githubusercontent.com/dyumra/DYHUB-Universal-Game/refs/heads/main/Mm2dyhubvw2.lua"
    }
    Tabs.SettingsTab:Toggle(
        {
            Title = "Auto Inject on Rejoin/Hop",
            Default = false,
            Callback = function(state)
                AutoInject.Enabled = state
                if state then
                    SetupAutoInject()
                    WindUI:Notify(
                        {
                            Title = "Auto Inject",
                            Content = "Autoinject is enabled! The script will restart automatically.",
                            Duration = 3
                        }
                    )
                else
                    WindUI:Notify({Title = "Auto Inject", Content = "Autoinjection disabled", Duration = 3})
                end
            end
        }
    )
    local function SetupAutoInject()
        if not AutoInject.Enabled then
            return
        end
        local TeleportService = game:GetService("TeleportService")
        local Players = game:GetService("Players")
        local LocalPlayer = Players.LocalPlayer
        spawn(
            function()
                wait(2)
                if AutoInject.Enabled then
                    pcall(
                        function()
                            loadstring(game:HttpGet(AutoInject.ScriptURL))()
                        end
                    )
                end
            end
        )
        LocalPlayer.OnTeleport:Connect(
            function(state)
                if ((state == Enum.TeleportState.Started) and AutoInject.Enabled) then
                    queue_on_teleport(
                        [[

                wait(2)

                loadstring(game:HttpGet("]] ..
                            AutoInject.ScriptURL .. [["))()

            ]]
                    )
                end
            end
        )
        game:GetService("Players").PlayerRemoving:Connect(
            function(player)
                if ((player == LocalPlayer) and AutoInject.Enabled) then
                    queue_on_teleport(
                        [[

                wait(2)

                loadstring(game:HttpGet("]] ..
                            AutoInject.ScriptURL .. [["))()

            ]]
                    )
                end
            end
        )
    end
    Tabs.SettingsTab:Button(
        {
            Title = "Manual Re-Inject",
            Callback = function()
                pcall(
                    function()
                        loadstring(game:HttpGet(AutoInject.ScriptURL))()
                        WindUI:Notify({Title = "Manual Inject", Content = "The script has been successfully reloaded!", Duration = 3})
                    end
                )
            end
        }
    )
    Tabs.SocialsTab:Paragraph(
        {
            Title = gradient("DYHUB .GG/DYHUB", Color3.fromHex("#ff0000"), Color3.fromHex("#000000")),
            Desc = "My Main Social",
            Image = "star",
            Color = "Red",
            Buttons = {
                {
                    Icon = "circle",
                    Title = "DYHUB DISCORD",
                    Callback = function()
                        if pcall(setclipboard, "https://dsc.gg/dyhub") then
                            WindUI:Notify(
                                {
                                    Title = "Copied!",
                                    Content = "Link copied to clipboard.",
                                    Duration = 3,
                                    Icon = "check-fill"
                                }
                            )
                        else
                            WindUI:Notify(
                                {
                                    Title = "Copy error",
                                    Content = "Failed to copy link. The setclipboard function may not be available..",
                                    Duration = 5,
                                    Icon = "x-fill"
                                }
                            )
                        end
                    end
                }
            }
        }
    )
    Tabs.SocialsTab:Paragraph(
        {
            Title = gradient("DYHUB GUNS.LOL", Color3.fromHex("#ff0000"), Color3.fromHex("#000000")),
            Desc = "My Another Social",
            Image = "star",
            Color = "Red",
            Buttons = {
                {
                    Title = "DYHUB SOCIAL",
                    Icon = "circle",
                    Callback = function()
                        if pcall(setclipboard, "https://guns.lol/DYHUB") then
                            WindUI:Notify(
                                {
                                    Title = "Copied!",
                                    Content = "Link copied to clipboard.",
                                    Duration = 3,
                                    Icon = "check-fill"
                                }
                            )
                        else
                            WindUI:Notify(
                                {
                                    Title = "Copy error",
                                    Content = "Failed to copy link. The setclipboard function may not be available..",
                                    Duration = 5,
                                    Icon = "x-fill"
                                }
                            )
                        end
                    end
                }
            }
        }
    )
    Tabs.ChangelogsTab:Code(
        {
            Title = "Changelogs:",
            Code = [[

    DYHUB • MM2 commands:

    |• Silent Aimbot

    |• All Sheriff Functions

    |• Better shot

    |• Fixed errors

    |• Shot variants [default; teleport]

    |• Faster shots

    |• New shot button

    |• Shot button settings

    |•All Murder Functions

    |• Fixed kill player

    |• Kill all function

    |• All Innocent Functions

    |• Grab GunDrop

    |• Auto Grab Gun Drop

    |• Grab gun and shoot murder function

    |• Fixed Notifications

    |• Fixed Check GunDrop Function

    |• Autofarm Money

    |• Autofarm variables [Tp; smooth; walk]

    |• Coin checker function

    |• Autofarm settings

    |• Tp to lobby function

]]
        }
    )
    Tabs.ChangelogsTab:Code(
        {
            Title = "Next:",
            Code = [[ The next update is [v1.1]

    In future we will be add:

    • Autofarm rare eggs

    • Fix bugs

    • New esp functions [tracers; names; highlights and more!]

    • Grab Gun Variables [Tp to gun; Gun tp to you]

]]
        }
    )
    local TeleportService = game:GetService("TeleportService")
    local HttpService = game:GetService("HttpService")
    local Players = game:GetService("Players")
    Tabs.ServerTab:Button(
        {
            Title = "Rejoin",
            Callback = function()
                local success, error =
                    pcall(
                    function()
                        TeleportService:TeleportToPlaceInstance(game.PlaceId, game.JobId, Players.LocalPlayer)
                    end
                )
                if not success then
                    warn("Rejoin error:", error)
                end
            end
        }
    )
    Tabs.ServerTab:Section({Title = ""})
    Tabs.ServerTab:Button(
        {
            Title = "Server Hop",
            Callback = function()
                local placeId = game.PlaceId
                local currentJobId = game.JobId
                local function serverHop()
                    local servers = {}
                    local success, result =
                        pcall(
                        function()
                            return HttpService:JSONDecode(
                                HttpService:GetAsync(
                                    "https://games.roblox.com/v1/games/" ..
                                        placeId .. "/servers/Public?sortOrder=Asc&limit=100"
                                )
                            )
                        end
                    )
                    if (success and result and result.data) then
                        for _, server in ipairs(result.data) do
                            if (server.id ~= currentJobId) then
                                table.insert(servers, server)
                            end
                        end
                        if (#servers > 0) then
                            TeleportService:TeleportToPlaceInstance(placeId, servers[math.random(#servers)].id)
                        else
                            TeleportService:Teleport(placeId)
                        end
                    else
                        TeleportService:Teleport(placeId)
                    end
                end
                pcall(serverHop)
            end
        }
    )
    Tabs.ServerTab:Button(
        {
            Title = "Join to Lower Server",
            Callback = function()
                local placeId = game.PlaceId
                local currentJobId = game.JobId
                local function joinLowerServer()
                    local servers = {}
                    local success, result =
                        pcall(
                        function()
                            return HttpService:JSONDecode(
                                HttpService:GetAsync(
                                    "https://games.roblox.com/v1/games/" ..
                                        placeId .. "/servers/Public?sortOrder=Asc&limit=100"
                                )
                            )
                        end
                    )
                    if (success and result and result.data) then
                        for _, server in ipairs(result.data) do
                            if ((server.id ~= currentJobId) and (server.playing < (server.maxPlayers or 30))) then
                                table.insert(servers, server)
                            end
                        end
                        table.sort(
                            servers,
                            function(a, b)
                                return a.playing < b.playing
                            end
                        )
                        if (#servers > 0) then
                            TeleportService:TeleportToPlaceInstance(placeId, servers[1].id)
                        else
                            TeleportService:Teleport(placeId)
                        end
                    else
                        TeleportService:Teleport(placeId)
                    end
                end
                pcall(joinLowerServer)
            end
        }
    )
    local HttpService = game:GetService("HttpService")
    local folderPath = "WindUI"
    makefolder(folderPath)
    local function SaveFile(fileName, data)
        local filePath = folderPath .. "/" .. fileName .. ".json"
        local jsonData = HttpService:JSONEncode(data)
        writefile(filePath, jsonData)
    end
    local function LoadFile(fileName)
        local filePath = folderPath .. "/" .. fileName .. ".json"
        if isfile(filePath) then
            local jsonData = readfile(filePath)
            return HttpService:JSONDecode(jsonData)
        end
    end
    local function ListFiles()
        local files = {}
        for _, file in ipairs(listfiles(folderPath)) do
            local fileName = file:match("([^/]+)%.json$")
            if fileName then
                table.insert(files, fileName)
            end
        end
        return files
    end
    Tabs.WindowTab:Section({Title = "Window"})
    local themeValues = {}
    for name, _ in pairs(WindUI:GetThemes()) do
        table.insert(themeValues, name)
    end
    local themeDropdown =
        Tabs.WindowTab:Dropdown(
        {
            Title = "Select Theme",
            Multi = false,
            AllowNone = false,
            Value = nil,
            Values = themeValues,
            Callback = function(theme)
                WindUI:SetTheme(theme)
            end
        }
    )
    themeDropdown:Select(WindUI:GetCurrentTheme())
    local ToggleTransparency =
        Tabs.WindowTab:Toggle(
        {Title = "Toggle Window Transparency", Callback = function(e)
                Window:ToggleTransparency(e)
            end, Value = WindUI:GetTransparency()}
    )
    Tabs.WindowTab:Section({Title = "Save"})
    local fileNameInput = ""
    Tabs.WindowTab:Input(
        {Title = "Write File Name", PlaceholderText = "Enter file name", Callback = function(text)
                fileNameInput = text
            end}
    )
    Tabs.WindowTab:Button(
        {Title = "Save File", Callback = function()
                if (fileNameInput ~= "") then
                    SaveFile(fileNameInput, {Transparent = WindUI:GetTransparency(), Theme = WindUI:GetCurrentTheme()})
                end
            end}
    )
    Tabs.WindowTab:Section({Title = "Load"})
    local filesDropdown
    local files = ListFiles()
    filesDropdown =
        Tabs.WindowTab:Dropdown(
        {Title = "Select File", Multi = false, AllowNone = true, Values = files, Callback = function(selectedFile)
                fileNameInput = selectedFile
            end}
    )
    Tabs.WindowTab:Button(
        {Title = "Load File", Callback = function()
                if (fileNameInput ~= "") then
                    local data = LoadFile(fileNameInput)
                    if data then
                        WindUI:Notify(
                            {
                                Title = "File Loaded",
                                Content = "Loaded data: " .. HttpService:JSONEncode(data),
                                Duration = 5
                            }
                        )
                        if data.Transparent then
                            Window:ToggleTransparency(data.Transparent)
                            ToggleTransparency:SetValue(data.Transparent)
                        end
                        if data.Theme then
                            WindUI:SetTheme(data.Theme)
                        end
                    end
                end
            end}
    )
    Tabs.WindowTab:Button(
        {Title = "Overwrite File", Callback = function()
                if (fileNameInput ~= "") then
                    SaveFile(fileNameInput, {Transparent = WindUI:GetTransparency(), Theme = WindUI:GetCurrentTheme()})
                end
            end}
    )
    Tabs.WindowTab:Button(
        {Title = "Refresh List", Callback = function()
                filesDropdown:Refresh(ListFiles())
            end}
    )
    local currentThemeName = WindUI:GetCurrentTheme()
    local themes = WindUI:GetThemes()
    local ThemeAccent = themes[currentThemeName].Accent
    local ThemeOutline = themes[currentThemeName].Outline
    local ThemeText = themes[currentThemeName].Text
    local ThemePlaceholderText = themes[currentThemeName].PlaceholderText
    function updateTheme()
        WindUI:AddTheme(
            {
                Name = currentThemeName,
                Accent = ThemeAccent,
                Outline = ThemeOutline,
                Text = ThemeText,
                PlaceholderText = ThemePlaceholderText
            }
        )
        WindUI:SetTheme(currentThemeName)
    end
    Tabs.CreateThemeTab:Colorpicker(
        {Title = "Background Color", Default = Color3.fromHex(ThemeAccent), Callback = function(color)
                ThemeAccent = color
            end}
    )
    Tabs.CreateThemeTab:Colorpicker(
        {Title = "Outline Color", Default = Color3.fromHex(ThemeOutline), Callback = function(color)
                ThemeOutline = color
            end}
    )
    Tabs.CreateThemeTab:Colorpicker(
        {Title = "Text Color", Default = Color3.fromHex(ThemeText), Callback = function(color)
                ThemeText = color
            end}
    )
    Tabs.CreateThemeTab:Button(
        {
            Title = "Update Theme",
            Callback = function()
                WindUI:AddTheme(
                    {
                        Name = currentThemeName,
                        Accent = ThemeAccent,
                        Outline = ThemeOutline,
                        Text = ThemeText,
                        PlaceholderText = ThemePlaceholderText
                    }
                )
                WindUI:SetTheme(currentThemeName)
                WindUI:Notify(
                    {
                        Title = "Topic updated",
                        Content = "New topic '" .. currentThemeName .. "' applied!",
                        Duration = 3,
                        Icon = "check-circle"
                    }
                )
            end
        }
    )
end
